# Histórias, Passos e Recomeços — paletas narrativas

## O que mudou

- Foram removidas as etiquetas automáticas de sentimentos e o filtro por categorias emocionais.
- Cada entrada agora combina duas cores escolhidas a partir do relato, do cenário ou das fotografias — não de um diagnóstico ou sentimento fixo.
- A mistura aparece nas bordas e em reflexos discretos dos cartões, com o corpo do texto preservado em fundo escuro para leitura confortável.
- Datas, textos, fotografias, expansão dos cartões e controles de teclado foram mantidos.
- O trabalho acadêmico de 2014 conserva a identidade visual de papel e azul, própria de seu conteúdo.

## Como definir as cores de uma nova entrada

Adicione a classe `entrada-contextual` ao artigo, por exemplo:

```html
<article class="cartao-entrada entrada-contextual" style="--tom-1:#74b8c8;--tom-2:#e4bb7e;">
```

Escolha duas cores associadas a elementos concretos da narrativa: luz do dia, ambiente,
objetos, clima, lugares, tonalidades da foto. Prefira o **contraste poético** entre
esses elementos, não uma tradução literal de "felicidade", "medo" ou "tristeza".
Nunca adicione chips ou rótulos psicológicos automaticamente.

## Critérios usados nas entradas atuais

01. A saída de casa: tons de lar e horizonte desconhecido (`#c68e78` + `#829fbd`).
02. O nascimento de Helena: amanhecer, pele e luz (`#e8ac93` + `#e0c47f`).
03. A cerca de madeira: tensão urbana e reconstrução (`#c47c69` + `#83a99b`).
04. Insônia e mudanças: madrugada e claridade incipiente (`#8395c5` + `#d8b18a`).
05. Conflitos domésticos: vinhos opacos e ar de casa (`#ba8092` + `#8ba2a9`).
06. SESMT: urgência física e ambiente clínico (`#ce7f7e` + `#84a8bf`).
07. Cajueiro e praia: mar e areia (`#6ab9b7` + `#dfbd78`).
08. Refúgio em família: verde e calor solar (`#84b69a` + `#e7b976`).
09. Covid-19: frio da convalescença e presença da filha (`#799fbd` + `#d7ae86`).
10. Plantas e bricolagem: folhagem e materiais manuais (`#79b998` + `#d1a376`).
11. Reaprender a se apresentar: incerteza e possibilidade (`#8fa1c9` + `#dda990`).
12. Casa à noite: aconchego dos filhos e encontro (`#e6bd86` + `#c99eab`).
13. Surpresas: desencontros e retomada de perspectiva (`#a999c5` + `#83b7b1`).
14. Novo emprego e Spy x Family: recomeço e vitalidade (`#e4aa79` + `#7fbea9`).
15. Autonomia e aceitação: céu aberto e caminho (`#80bac3` + `#8fc49c`).
16. Escolhas profissionais: sobriedade e compromisso (`#8ca2ba` + `#c5a180`).
17. Metas de vendas: pressão e ambiente corporativo (`#c48076` + `#8ca1b6`).
18. Planos interrompidos: nuvem e luz no horizonte (`#9a95bc` + `#d7b683`).
19. Romance na chuva: rosa suave e azul da água (`#d9a1b5` + `#83a6c1`).
20. Distância da filha: céu profundo e procura de equilíbrio (`#859cc5` + `#d3b991`).
21. Memória fotográfica: cores alegres e brinquedos (`#d2a477` + `#bb8ead`).
22. Fotografia da boneca: rosa de embalagem e luz (`#ce8cae` + `#e0bb87`).
23. Fotografia na praia: azul das águas e areia (`#78b2bd` + `#d6b68c`).
24. Fotografia na piscina: água clara e sol (`#74b8c8` + `#e4bb7e`).
25. Fotografia no carro: tons de janela e luz suave (`#839ab4` + `#c3b7a4`).
26. Fotografia azul: luz azul e madeira (`#7d9ed4` + `#b99e8d`).
27. Helena: luminosidade da infância e crescimento (`#e2bb86` + `#78b2a5`).
28. Glênia: delicadeza, equilíbrio e calor (`#aaa2cf` + `#e0ae95`).
29. Cumplicidade: proximidade e luz partilhada (`#ca94a9` + `#d8b17e`).
30. Quatro imagens: interiores quentes e detalhes azuis (`#d2a17c` + `#8aa5ba`).
